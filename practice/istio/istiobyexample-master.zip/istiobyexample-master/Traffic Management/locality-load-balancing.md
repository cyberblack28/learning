# 例から学ぶIstio

## ローカリティロードバランシング

大規模なグローバルアプリケーションを実行している場合、複数のリージョンでサービスを実行している可能性があります。同じサービスのレプリカが複数ある場合は、レイテンシを最小限に抑えるために、クライアント要求を最も近いサーバーに転送することができます。また、1つのリージョンがダウンした場合にフェイルオーバーを処理し、トラフィックを最も近い利用可能なサービスに転送する方法が必要になる場合もあります。

Istioは、locality load balancingと呼ばれる機能を使用して、リージョンのトラフィックを自動的に処理してくれます。方法を見てみましょう。

![locality load balancing](https://istiobyexample.dev/images/loc-default.png)

ここでは、us-centralとus-eastの2つの異なるクラウドリージョンで実行されている2つのKubernetesクラスターがあります。 Istioコントロールプレーンはus-eastで実行されており、両方のクラスターで実行されているサービスが互いに到達できるように、単一の[Control Plane Istio](https://github.com/GoogleCloudPlatform/istio-samples/tree/191859c03e73da7e98d451c967cefe24101d1933/multicluster-gke/single-control-plane#demo-multicluster-istio--single-control-plane)マルチクラスターをセットアップしました。

両方のクラスターを起動したときに、クラウドプロバイダーはリージョン固有の failure-domain をKubernetesノードに追加しました。

```
failure-domain.beta.kubernetes.io/region: us-central1
failure-domain.beta.kubernetes.io/zone: us-central1-b
```

Istioはこれらのローカリティラベルをリクエストに入力し、Istioがリクエストを最も近い利用可能なリージョンにリダイレクトできるようにします。


両方のクラスターは、echoと呼ばれる Istio-injected サービスを実行しています。これは、ポート80でアクセスが来たときにその内容を返します。中央クラスターは、echo.default.svc.cluster.local：80を毎秒呼び出す loadgen サービスも実行しています。


デフォルトでは、Kubernetes Serviceの動作は、両クラスタの2つの echo サーバー間でのラウンドロビン方式です。

```
$ 🌊 Hello World! - EAST
$ ✨ Hello World! - CENTRAL
$ 🌊 Hello World! - EAST
$ ✨ Hello World! - CENTRAL
```
eastクラスタに [Outlier Detection](https://istio.io/docs/reference/config/networking/destination-rule/#OutlierDetection)定義を Istio DestinationRule マニフェストファイルに追加することにより、locality load balancing を有効にできます。

```
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: echo-outlier-detection
spec:
  host: echo.default.svc.cluster.local
  trafficPolicy:
    connectionPool:
      tcp:
        maxConnections: 1000
      http:
        http2MaxRequests: 1000
        maxRequestsPerConnection: 10
    outlierDetection:
      consecutiveErrors: 7
      interval: 30s
      baseEjectionTime: 30s
```

これで、すべてのloadgenリクエストは、us-centralで実行されている最も近い echo のインスタンスにルーティングされます。

```
$ ✨ Hello World! - CENTRAL
$ ✨ Hello World! - CENTRAL
$ ✨ Hello World! - CENTRAL
```

![loc-locality](https://istiobyexample.dev/images/loc-locality.png)

us-centralで実行されているechoデプロイメントを削除すると、
Istioは loadgen リクエストをus-eastで実行されているecho Podにリダイレクトします。

```
$ 🌊 Hello World! - EAST
$ 🌊 Hello World! - EAST
$ 🌊 Hello World! - EAST
```

![loc-failover](https://istiobyexample.dev/images/loc-failover.png)


Istioのグローバルインストール設定で、メッシュ全体のトラフィックの割合に基づく負荷分散ルールを追加することもできます。

```
    localityLbSetting:
      distribute:
      - from: us-central1/*
        to:
          us-central1/*: 20
          us-east1/*: 80
```

これで、両方のクラスターで実行されているすべてのサービスが、us-east と us-central の間でリクエストを80/20共有します。 VirtualServicesは必要ありません。

```
$ 🌊 Hello World! - EAST
$ 🌊 Hello World! - EAST
$ 🌊 Hello World! - EAST
$ 🌊 Hello World! - EAST
$ ✨ Hello World! - CENTRAL
```

![loc-splittraffic](https://istiobyexample.dev/images/loc-splittraffic.png)

Istioによる Locality Load Balancing の詳細については、[Istioドキュメント](https://istio.io/docs/ops/configuration/traffic-management/locality-load-balancing/)をご覧ください。