# 例から学ぶIstio

## カナリアデプロイメント

カナリアデプロイメントは、新しいバージョンのサービスを安全に展開するための戦略です。 Istioを使用すると、割合ベースの[トラフィック分割](https://istio.io/docs/concepts/traffic-management/#routing-versions)を使用して、少量のトラフィックを新しいバージョンに転送できます。それから、v2で[カナリア分析](https://cloud.google.com/blog/products/devops-sre/canary-analysis-lessons-learned-and-best-practices-from-google-and-waze)を実行して（レイテンシーやエラー率をチェックするなど）、最終的にすべてのトラフィックを処理するまで新しいバージョンでより多くのトラフィックを転送できます。

![カナリアデプロイメント](https://istiobyexample.dev/images/canary_diagram.png)

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: helloworld
spec:
  hosts:
    - helloworld
  http:
  - route:
    - destination:
        host: helloworld
        subset: v1
      weight: 90
    - destination:
        host: helloworld
        subset: v2
      weight: 10
```

```
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: helloworld
spec:
  host: helloworld
  subsets:
  - name: v1
    labels:
      version: v1
  - name: v2
    labels:
      version: v2
```
