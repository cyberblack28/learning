# 例から学ぶIstio

## gRPC

[gRPC](https://grpc.io/)は、[HTTP/2](https://www.cncf.io/blog/2018/08/31/grpc-on-http-2-engineering-a-robust-high-performance-protocol/)上に構築されたサービス用の通信プロトコルです。[リソース](https://en.wikipedia.org/wiki/Representational_state_transfer)に基づくREST over HTTP/1とは異なり、gRPCは[サービス定義](https://grpc.io/docs/guides/concepts/)に基づいています。[プロトコルバッファ](https://developers.google.com/protocol-buffers/)（「プロト」）と呼ばれる形式でサービス定義を指定します。これは、送信用に小さなバイナリ形式にシリアル化できます。


gRPCを使用すると、.protoファイルからボイラープレートコードを[複数のプログラミング言語](https://grpc.io/docs/quickstart/)に生成できるため、gRPCはポリグロットマイクロサービスにとって理想的な選択肢となります。


gRPCは[TLS](https://grpc.io/docs/guides/auth/)や[クライアント側の負荷分散](https://grpc.io/blog/grpc-load-balancing/#proxy-or-client-side)などのネットワークユースケースをサポートしていますが、IstioをgRPCアーキテクチャに追加すると、テレメトリの収集、トラフィックルールの追加、[RPCレベルの承認](https://istio.io/blog/2018/istio-authorization/#rpc-level-authorization)の設定に役立ちます。 Istioは、トラフィックがHTTP、TCP、gRPC、およびデータベースプロトコルの組み合わせである場合、すべてのトラフィックタイプに同じIstio APIを使用できるため、有用な管理レイヤーも提供できます。

[Istio](https://istio.io/about/feature-stages/#traffic-management)とそのデータプレーンプロキシである[Envoy](https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/other_protocols/grpc#arch-overview-grpc)は、両方ともgRPCをサポートしています。IstioでgRPCトラフィックを管理する方法を見てみましょう。

![IstioでgRPCトラフィック管理](https://istiobyexample.dev/images/grpc.png)

こでは、クライアントとサーバーの2つのgRPCサービスを実行しています。クライアントは、サーバーの /SayHello 関数に対して2秒ごとにRPC呼び出しを行います。

IstioをgRPC Kubernetes Serviceに追加するには、Kubernetes Serviceのポートに[ラベル付け](https://istio.io/docs/ops/deployment/requirements/)という1つの前提条件があります。サーバーのポートには次のラベルが付いています。

```
apiVersion: v1
kind: Service
metadata:
  name: server
spec:
  selector:
    app: server
  type: ClusterIP
  ports:
  - name: grpc # important!
    protocol: TCP
    port: 8080
```

アプリケーションを展開すると、[サービスグラフ](https://kiali.io/)でクライアントとサーバー間のこのトラフィックを確認できます。

![Kiali]](https://istiobyexample.dev/images/grpc-kiali.png)

GrafanaでサーバーのgRPCトラフィックメトリックを表示することもできます。

![Grafana](https://istiobyexample.dev/images/grpc-server-healthy.png)

そして、Istioトラフィックルールを適用して、10秒の遅延[障害](https://istio.io/docs/tasks/traffic-management/fault-injection/)をサーバーに起こします。このルールをカオステストシナリオに適用して、このアプリケーションの復元性をテストすることができます。

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: server-fault
spec:
  hosts:
  - server
  http:
  - fault:
      delay:
        percentage:
          value: 100.0
        fixedDelay: 10s
    route:
    - destination:
        host: server
        subset: v1
```

これにより、クライアントRPCがタイムアウトします（発信要求期間）。

![発信要求期間](https://istiobyexample.dev/images/grpc-grafana-client-fault-inject.png)

gRPCとIstioをより詳しく学ぶ：

- [Istio ドキュメント-トラフィック マネージメント](https://istio.io/docs/concepts/traffic-management/#traffic-routing-and-configuration)
- [ブログ投稿記事](https://cloud.google.com/solutions/using-istio-for-internal-load-balancing-of-grpc-services)