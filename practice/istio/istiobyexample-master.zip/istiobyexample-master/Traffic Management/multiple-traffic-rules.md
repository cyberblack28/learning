# 例から学ぶIstio

## 複数トラフィックルール

Istioは、[リダイレクト](https://istio.io/docs/reference/config/networking/virtual-service/#HTTPRewrite)や[トラフィック分割](https://istio.io/docs/tasks/traffic-management/traffic-shifting/)から[ミラーリング](https://istio.io/docs/tasks/traffic-management/mirroring/)や[再試行ロジック](https://istio.io/docs/concepts/traffic-management/#retries)まで、さまざまな[トラフィック管理](https://istio.io/docs/concepts/traffic-management/)の使用例をサポートしています。 Istio [VirtualService](https://istio.io/docs/reference/config/networking/virtual-service/)を作成して、サービスのためにこれらのポリシーの1つを定義した場合、同じリソースにさらにトラフィック管理ルールを追加するのは簡単です。この例は、1つのKubernetesに基づいたサービスに複数のトラフィックルールを適用する方法を示しています。

たとえば、新聞社のWebサイトのフロントエンドエンジニアリングチームにいるとします。ユーザー向けのフロントエンドサービスは、articlesというバックエンドに依存しており、articlesのコンテンツとメタデータをJSONとして提供します。しかし、articlesチームはサービスを新しい言語でリファクタリングしており、新しい変更を頻繁に展開しています。これにより、フロントエンドで予期しないエラーが発生し、レガシーarticlesサービスの動作に依存していました。さらに複雑なことに、以前は別のブログサービスで提供されていた新聞のブログが、articlesサービスに組み込まれただけでした。現在、すべてのブログ投稿は /beta/blogパスで提供されるarticlesです。

フロントエンドに代わって articles の動作を固定するために、articlesのIstioトラフィックポリシーを作成します。articlesに対するフロントエンドのトラフィック要件には、/breaking-news articlesのno-cacheヘッダーを返す、/blogを/beta /blogに書き換える、すべてのリクエストで2秒のタイムアウトを適用するなどがあります。

![multiple-functionality](https://istiobyexample.dev/images/multiple-functionality.png)

この集約機能を取得するために、/breaking-newsの[レスポンスヘッダの変更](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/response-headers.md)、/blogのURL書き換え、およびarticlesサービスへのデフォルトのフォールスルーの3つのhttpルールを使用して、articlesに対して1つのVirtualServiceを作成します。 3つのルールすべてに2秒のタイムアウトがあります。

![multiple-vs](https://istiobyexample.dev/images/multiple-vs.png)

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: articles-vs
spec:
  hosts:
  - articles
  http:
  - match: # RULE 1 - BREAKING NEWS
    - uri:
        prefix: "/article/breaking-news"
    route:
    - destination:
        host: articles
      headers:
        response:
          add:
            no-cache: "true"
      timeout: 2s
  - match: # RULE 2 - BLOG URI REWRITE
    - uri:
        prefix: /blog
    rewrite:
      uri: /beta/blog
    route:
    - destination:
        host: articles
      timeout: 2s
  - route: # RULE 3 / DEFAULT - TIMEOUT
    - destination:
        host: articles
    timeout: 2s
    weight: 100
```

このVirtualServiceをクラスターに適用した後、frontend Podで実行してarticlesサービスにアクセスし、ルールが有効になっていることを確認できます。たとえば、/breaking-news記事をリクエストすると、応答にno-cache：trueヘッダーが追加されます。

```
$ curl -v http://articles:80/article/breaking-news/2020/astrophysics-discovery

< HTTP/1.1 200 OK
< date: Wed, 15 Jan 2020 22:10:52 GMT
...
< no-cache: true
```

/blogで始まるパスをリクエストすると、/beta /blogに書き直され、articlesは/beta /blogパスを提供することが分かります。

```
$ curl http://articles:80/blog/2020/new-engineering-blog

{"id":91385,"title":"Welcome to the new News Blog!" ...
```

最後に、articlesサービスのアプリケーションコードに10秒のスリープを書き込むと、2秒のタイムアウトの動作を確認できます。

```
$ curl  http://articles:80/

upstream request timeout
```

![multiple-fault](https://istiobyexample.dev/images/multiple-fault.png)


注：1つのVirtualServiceに複数のルールを追加すると、[ルールは上から順に評価](https://istio.io/docs/concepts/traffic-management/#routing-rule-precedence)されます。したがって、Articles VirtualServiceに[fault injection](https://istio.io/docs/tasks/traffic-management/fault-injection/#injecting-an-http-abort-fault)ルールを追加して、HTTPステータスコード404：すべてのリクエストで見つかりませんを返す場合、そのルールは他の3つをオーバーライドし、Articlesサービス全体を停止します。

```
curl -v http://articles:80
...
* Connected to articles (10.0.21.31) port 80

< HTTP/1.1 404 Not Found
```

VirtualServicesにはこのルールの優先順位があるため、複雑なIstioトラフィックポリシーを検証およびテストすることが重要です。上記で行ったように、「フォールスルー」またはデフォルトのルールを追加して、特定のホストに対するすべてのリクエストが確実にルーティングされるようにすることもお勧めします。