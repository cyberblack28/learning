# 例から学ぶIstio

## レスポンスヘッダの変更

Istioでは、[HTTPリクエストヘッダー](https://istio.io/docs/tasks/traffic-management/request-routing/#route-based-on-user-identity)に基づいてルーティングするトラフィックルールを適用できます。 Istioを使用して[レスポンスヘッダーを変更](https://istio.io/docs/reference/config/networking/virtual-service/#Headers)することもできます。これは、アプリケーションで生成されたヘッダーを削除する場合、またはアプリケーションコードを変更せずにレスポンスヘッダーを追加する場合に便利です。

![Modify Response Headers](https://istiobyexample.dev/images/modify-response-headers.png)

この例では、Istio [VirtualService](https://istio.io/docs/concepts/traffic-management/#virtual-services)を適用して新しいヘッダー（hello：world）を追加し、set-cookieヘッダーを削除します。次に、デフォルトゲートウェイを介してサービスメッシュに入るすべてのクライアント要求は、これらの変更されたヘッダーを受け取ります。

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: frontend-ingress
spec:
  hosts:
  - "*"
  gateways:
  - frontend-gateway
  http:
  - route:
    - destination:
        host: frontend
        port:
          number: 80
      headers:
        response:
          add:
            hello: world
          remove:
          - "set-cookie"
```

VirtualServiceを適用する前に、フロントエンドサービスは次の応答ヘッダーを返します。

```
HTTP/1.1 200 OK
set-cookie: shop_session-id=432bef95-0d25-4754-80c8-3904c2e329e9; Max-Age=172800
date: Wed, 18 Sep 2019 16:26:01 GMT
content-type: text/html; charset=utf-8
x-envoy-upstream-service-time: 45
server: istio-envoy
transfer-encoding: chunked
```

次に、kubectl apply でVirtualServiceを実行すると、レスポンスヘッダーを変更するようにEnvoyが正常に構成されていることがわかります。

```
HTTP/1.1 200 OK
date: Wed, 18 Sep 2019 16:26:24 GMT
content-type: text/html; charset=utf-8
x-envoy-upstream-service-time: 85
hello: world
server: istio-envoy
transfer-encoding: chunked
```