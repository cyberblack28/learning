# 例から学ぶIstio

## Ingress

Ingressトラフィックとは、クラスターの外部からメッシュに入るトラフィックのことです。 Kubernetesは、Ingressトラフィックを処理する[方法](https://kubernetes.io/docs/concepts/services-networking/ingress/)を[提供](https://kubernetes.io/docs/concepts/services-networking/service/#loadbalancer)します。 Istioを使用すると、代わりにゲートウェイでIngressトラフィックを管理できます。

[ゲートウェイ](https://istio.io/docs/reference/config/networking/gateway/)は、インバウンドトラフィックを負荷分散するEnvoyプロキシのスタンドアロンセットです。 Istioは、パブリックIPアドレスを持つデフォルトのIngressGatewayを展開します。これは、サービスメッシュ内のアプリケーションをインターネットに公開するように構成できます。


Istio Gatewayには、従来のKubernetes Ingressよりも2つの重要な利点があります。ゲートウェイは別のEnvoyプロキシであるため、Istioを使用して、サービス間の東西トラフィックを構成するのと同じ方法でトラフィックを構成できます（トラフィックの分割、リダイレクト、再試行ロジック）。

ゲートウェイは、[サイドカー](https://istio.io/docs/concepts/what-is-istio/#envoy)プロキシと同様にメトリック（リクエストレート、エラーレート）も転送するため、[サービスグラフ](https://istio.io/docs/tasks/observability/kiali/#generating-a-service-graph)でイングレストラフィックを表示し、クライアントに直接サービスを提供するフロントエンドサービスにきめ細かな[SLO](https://landing.google.com/sre/sre-book/chapters/service-level-objectives/)を設定できます。

稼働中のゲートウェイを見てみましょう。

![ゲートウェイ](https://istiobyexample.dev/images/ingress.png)


ここでは、helloアプリケーションはPod内のコンテナで実行されます。PodにはIstioサイドカープロキシコンテナがあります。このPodには、hello frontと呼ばれるKubernetes Serviceがあります。 hello.comからのインバウンドトラフィックをhello Serviceに転送します。

最初に、hello.comドメインから解決するすべてのホストに対して、デフォルトのIstio IngressGatewayでポート80を開くゲートウェイリソースが必要です。

```
apiVersion: networking.istio.io/v1alpha3
kind: Gateway
metadata:
  name: hello-gateway
spec:
  selector:
    istio: ingressgateway # use the default IngressGateway
  servers:
  - port:
      number: 80
      name: http
      protocol: HTTP
    hosts:
    - "hello.com"
```

（注：自分で、そのホストのDNSをIstio IngressGateway外部IPアドレスに解決する必要があります。）

次に、トラフィックを[IngressGateway](https://istio.io/docs/tasks/traffic-management/ingress/ingress-control/)からポート80のdefault Namespaceで実行されるhelloバックエンドサービスに転送するVirtualServiceが必要です。

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: frontend-ingress
spec:
  hosts:
  - "hello.com"
  gateways:
  - hello-gateway
  http:
  - route:
    - destination:
        host: hello.default.svc.cluster.local
        port:
          number: 80
```