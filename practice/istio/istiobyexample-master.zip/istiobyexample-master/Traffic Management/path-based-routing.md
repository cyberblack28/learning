# 例から学ぶIstio

## Pathに基づいたルーティング

Istioと[Envoy](https://istio.io/docs/concepts/what-is-istio/#envoy)はアプリケーショントラフィックレイヤー（L7）で動作し、HTTPヘッダーなどの属性に基づいてトラフィックを転送および負荷分散できます。この例は、[リクエストURIパスに基づいた](https://istio.io/docs/concepts/traffic-management/#match-request-uri)トラフィックを転送する方法となります。


この例では、myapp はWebサイトのサーバーバックエンドであり、フロントエンドによって使用されます。エンジニアリングチームは、新しいユーザー認証サービス auth を実装しました。auth は現在、別のサービスとして動作しています。

Istio [match rule](https://istio.io/docs/reference/config/networking/virtual-service/#HTTPMatchRequest) を使用して、/loginプレフィックスを含むすべてのリクエストを新しい認証サービスにリダイレクトし、他のすべての myapp リクエストを既存のバックエンドに転送します。

![Path-Based Routing](https://istiobyexample.dev/images/path-based-urimatch.png)

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: auth-redirect
spec:
  hosts:
  - myapp
  http:
  - match:
    - uri:
        prefix: "/login"
    route:
    - destination:
        host: auth
  - route:
    - destination:
        host: myapp
```