# 例から学ぶIstio

## トラフィックミラーリング

信頼性を確保するには、本番環境でサービスをテストすることが重要です。稼働中の本番トラフィックをサービスの新しいバージョンに送信すると、継続的な統合と機能テスト中にテストされなかったバグを明らかにできます。


Istioを使用すると、トラフィックミラーリングを使用して、別のサービスへのトラフィックを複製できます。[カナリアデプロイメント](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/canary.md)パイプラインの一部としてトラフィックミラーリングルールを組み込むことができます。これにより、ライブトラフィックをサービスに送信する前にサービスの動作を分析できます。

この例では、Kubernetesにビデオ処理パイプラインをデプロイしました。 render サービスは encode-prod サービスに依存しており、encode-encode-test の新しいバージョンをロールアウトしたいと考えています。

![traffic mirroing](https://istiobyexample.dev/images/traffic-mirror.png)

Istio VirtualServiceを使用して、すべてのencode-prodトラフィックをencode-testにミラーリングできます。render 用のクライアント側のEnvoyプロキシは、encode-prod（リクエストパス）とencode-test（ミラーリングパス）の両方にリクエストを送信します。 prodとtestは、Istio DestinationRuleで指定されている encode Kubernetes Serviceの2つのサブセットです。

注：renderは、encode-testからの応答の受信を[待機しません](https://www.envoyproxy.io/docs/envoy/latest/api-v2/api/v2/route/route.proto#route-routeaction-requestmirrorpolicy) —ミラーリングされた要求は「実行して忘れる」ことになります。

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: encode-mirror
spec:
  hosts:
    - encode
  http:
  - route:
    - destination:
        host: encode
        subset: prod
      weight: 100
    mirror:
      host: encode
      subset: test
```

```
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: encode
spec:
  host: encode
  subsets:
  - name: prod
    labels:
      version: prod
  - name: test
    labels:
      version: test
```