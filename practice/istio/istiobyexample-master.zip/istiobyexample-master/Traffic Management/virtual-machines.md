# 例から学ぶIstio

## 仮想マシン

Kubernetesでコンテナ化されたサービスを実行すると、自動スケーリング、依存関係の分離、リソースの最適化など、多くのメリットが得られます。 IstioをKubernetes環境に追加すると、多数のコンテナーを操作している場合でも、メトリクスの集計とポリシー管理を大幅に簡略化できます。

しかし、ステートフルサービス、またはレガシーアプリケーションが仮想マシンで実行されている場合はどうでしょうか。または、VMからコンテナーに移行する場合はどうなりますか？心配はいりません。仮想マシンをIstioサービスメッシュに統合できます。方法を見てみましょう。

![vm-call-flow](https://istiobyexample.dev/images/vm-call-flow.png)

この例では、ローカルライブラリのWebアプリケーションを実行しています。このウェブアプリには複数のバックエンドがあり、すべてKubernetesクラスターで実行されています。 Kubernetesのワークロードの1つ、inventory、PostgreSQLデータベースと通信し、ライブラリに追加された新しい本毎にレコードを書き込みます。このデータベースは、別のクラウドリージョンの仮想マシンで実行されています。

VMベースのデータベースであるPostgreSQLの完全なIstio機能を取得するには、VMにIstioサイドカープロキシをインストールし、クラスターで実行されているIstioコントロールプレーンと通信するように構成する必要があります。（これは外部の[ServiceEntries](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/external-services.md)を追加することとは異なることに注意してください。）Postgresデータベースを3つのステップでメッシュに追加できます。[GitHubのデモのコマンド](https://github.com/askmeegs/postgres-library/tree/0241acce9d7e2cede0de8ac9baa1338624f716eb#-postgres-library)に従ってください。

![vm-architecture](https://istiobyexample.dev/images/vm-architecture.png)

1. PodからVMへのトラフィック用の[ファイアウォールルールを作成](https://github.com/askmeegs/postgres-library#5-allow-pod-ip-traffic-to-the-vm)します。これにより、Kubernetes PodのCIDR範囲からVMベースのワークロードに直接トラフィックを送信できます。
2. [IstioをVMにインストール](https://github.com/askmeegs/postgres-library#6-prepare-a-clusterenv-file-to-send-to-the-vm)します。サービスアカウントキー、およびVMサービスが公開するポート（この場合は、PostgreSQLクライアントポート5432）をコピーします。 VMの/etc /hostsを更新して、クラスターで実行されているIstio IngressGatewayを介してistio.pilotおよびistio.citadelトラフィックをルーティングします。次に、VMにIstioサイドカープロキシとノードエージェントをインストールします。ノードエージェントは、相互TLS認証のために、サイドカープロキシにマウントするクライアント証明書を生成します。 systemctlを使用してプロキシとノードエージェントを起動します。
3. [VMワークロードをKubernetesに登録](https://github.com/askmeegs/postgres-library#8-register-the-vm-with-istio-running-on-the-gke-cluster)します。Postgresデータベースをメッシュに追加するには、2つのKubernetesリソースが必要です。 1つはServiceEntryです。これにより、Kubernetes DNS名が仮想マシンのIPアドレスにルーティングされます。最後に、そのDNSエントリを作成するには、Kubernetes Serviceが必要です。これにより、クライアントPodが postgres-1-vm.default.svc.cluster.local で[データベース接続を開始](https://github.com/askmeegs/postgres-library/blob/master/main.go#L39)できるようになります。これを行うには、istioctl registerコマンドを使用できます。

これで、ポッドログを表示して、Kubernetesに基づくクライアントがデータベースに正常に書き込めることを確認できます。

```
postgres-library-6bb956f86b-dt94x server ✅ inserted Fun Home
postgres-library-6bb956f86b-dt94x server ✅ inserted Infinite Jest
postgres-library-6bb956f86b-dt94x server ✅ inserted To the Lighthouse
```

また、VMでEnvoyアクセスログを表示することにより、VMで実行されているサイドカープロキシがポート5432で受信トラフィックを傍受していることを確認できます。

```
$ tail /var/log/istio/istio.log

[2019-11-14T19:09:00.174Z] "- - -" 0 - "-" "-" 268 441 194 - "-" "-" "-" "-"
"127.0.0.1:5432" inbound|5432|tcp|postgresql-1-vm.default.svc.cluster.local
127.0.0.1:54104 10.128.0.14:5432 10.24.2.23:40190
outbound_.5432_._.postgresql-1-vm.default.svc.cluster.local -
```

KialiサービスグラフでTCPメトリックフローを確認することもできます。

![vm-kiali](https://istiobyexample.dev/images/vm-kiali.png)

ここから、マルチ環境サービスメッシュに任意のIstioトラフィックまたはセキュリティポリシーを使用できます。たとえば、メッシュ全体の相互TLSポリシーを追加することで、クラスターとVM間のすべてのトラフィックを暗号化できます。

```
apiVersion: "authentication.istio.io/v1alpha1"
kind: "MeshPolicy"
metadata:
  name: "default"
spec:
  peers:
  - mtls: {}
---
apiVersion: "networking.istio.io/v1alpha3"
kind: "DestinationRule"
metadata:
  name: "default"
  namespace: "istio-system"
spec:
  host: "*.local"
  trafficPolicy:
    tls:
      mode: ISTIO_MUTUAL
```

より詳しく学ぶ:

- [ご自身の環境で動かしてみましょう](https://github.com/askmeegs/postgres-library)
- [別のサンプル例](https://github.com/GoogleCloudPlatform/istio-samples/tree/master/mesh-expansion-gce)
- [Istioのドキュメントをご覧ください](https://istio.io/docs/examples/virtual-machines/single-network/)

