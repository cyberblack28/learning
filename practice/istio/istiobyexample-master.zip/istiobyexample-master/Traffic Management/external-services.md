# 例から学ぶIstio

## 外部サービス

多くの場合、[サービスメッシュ](https://istio.io/docs/concepts/what-is-istio/#what-is-a-service-mesh)は1つの環境にまたがっています。たとえば、1つのKubernetesクラスターです。そして、一緒に、その環境に接続されているすべてのサービスがそのメッシュの管理ドメインを形成し、そこからメトリックを表示してポリシーを設定できます。

しかし、もしクラスターの外部でもサービスを実行している場合、または外部APIに依存している場合はどうでしょうか？

心配ありません。Istioには、[ServiceEntry](https://istio.io/docs/concepts/traffic-management/#service-entries)と呼ばれるリソースを提供します。これにより、外部のサービス（保持していないサービスも含む）を論理的にメッシュに取り込むことができます。

外部ホスト名のServiceEntryを作成すると、その外部サービスに到達するまでのメトリックとトレースを表示できます。これらの外部サービスに[再試行ロジック]()などのトラフィックポリシーを設定することもできます。 ServiceEntriesを追加すると、Istio管理ドメインの範囲が効果的に広がります。
例を見てみましょう。

![外部サービス](https://istiobyexample.dev/images/ext-currency.png)

ここでは、ユーザーの地域に基づいて製品の価格を変換する責任を負う、通貨サービスを備えたグローバルストアWebサイトを実行しています。リアルタイムの為替レートを提供するために、サードパーティの通貨変換APIである[欧州中央銀行](https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html)と連携しています。

メッシュ内のサービスからこの外部APIへのすべての呼び出しに3秒のタイムアウトを設定します。これを行うには、2つのIstioリソースが必要です。

まず、メッシュに欧州中央銀行のホスト名 ecb.europa.eu を論理的に追加する ServiceEntry：

```
apiVersion: networking.istio.io/v1alpha3
kind: ServiceEntry
metadata:
  name: currency-api
spec:
  hosts:
  - www.ecb.europa.eu
  ports:
  - number: 80
    name: http
    protocol: HTTP
  - number: 443
    name: https
    protocol: HTTPS
```

次に、APIへの呼び出しのタイムアウトを設定する VirtualService トラフィックルール：

```
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: currency-timeout
spec:
  hosts:
    - www.ecb.europa.eu
  http:
  - timeout: 3s
    route:
      - destination:
          host: www.ecb.europa.eu
        weight: 100
```

通貨APIのServiceEntryを作成すると、[Kialiサービスグラフ](https://istio.io/docs/tasks/observability/kiali/)にecb.europa.euが自動的に表示されます（誰が呼び出しているかがすぐにわかります）。

![Kialiサービスグラフ](https://istiobyexample.dev/images/ext-servicegraph.png)

また、この外部サービスを自動的に[Grafanaダッシュボード](https://istio.io/docs/tasks/observability/metrics/using-istio-dashboard/)で取得して、応答コードや遅延などのデータを表示します。

![Grafanaダッシュボード](https://istiobyexample.dev/images/ext-grafana.png)

外部サービスの管理と保護の詳細については、Istioのドキュメントを参照してください。