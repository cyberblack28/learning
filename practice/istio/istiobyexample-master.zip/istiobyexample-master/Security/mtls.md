# 例から学ぶIstio

## 相互TLS

マイクロサービスアーキテクチャは、ネットワーク上の要求が増えることと、悪意のある当事者がトラフィックを傍受する機会が増えることを意味します。[相互TLS（mTLS）認証](https://en.wikipedia.org/wiki/Mutual_authentication)は、[証明書](https://www.internetsociety.org/deploy360/tls/basics/)を使用してサービストラフィックを暗号化する方法です。

Istioを使用すると、すべてのサービスにわたるmTLSの適用を自動化できます。以下では、メッシュ全体に対してmTLSを有効にします。クラスター内の2つのPod（クライアントとサーバー）は、mTLSポリシーを使用して安全な接続を確立しているところが示されています。

![mtls](https://istiobyexample.dev/images/mtls.png)

```
apiVersion: authentication.istio.io/v1alpha1
kind: MeshPolicy
metadata:
  name: default
spec:
  peers:
  - mtls:
      mode: STRICT
```

```
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: default
  namespace: istio-system
spec:
  host: "*.local"
  trafficPolicy:
    tls:
      mode: ISTIO_MUTUAL
```

ここでは、MeshPolicyは要求を受信するすべてのサービス（サーバー側）にTLSを適用し、DestinationRuleは要求を送信するすべてのサービス（クライアント側）にTLSを適用し、相互（「両方」）のTLSを作成します。

認証フロー：

1. クライアントアプリケーションコンテナーはプレーンテキストのHTTPリクエストをサーバーに送信します。
2. クライアントプロキシコンテナーがアウトバウンド要求を傍受します。
3. クライアントプロキシは、サーバー側プロキシとTLSハンドシェイクを実行します。このハンドシェイクには、証明書の交換が含まれます。これらの証明書は、Istioによってプロキシコンテナーにプリロードされます。
4. クライアントプロキシは、サーバーの証明書に対して安全な名前付けチェックを実行し、承認されたIDがサーバーを実行していることを確認します。
5. クライアントとサーバーは相互TLS接続を確立し、サーバープロキシは要求をサーバーアプリケーションコンテナーに転送します。

詳しく学ぶ：

- [Istio Docs-認証](https://istio.io/docs/concepts/security/#authentication)
- [サンプル：認証](https://github.com/GoogleCloudPlatform/istio-samples/tree/77fb1dfb690d28517e410df2911e255d54e3450e/security-intro#authentication)
- [タスク-認証ポリシー](https://istio.io/docs/tasks/security/authentication/authn-policy/)
- [タスク-相互TLSの詳細](https://istio.io/pt-br/docs/tasks/security/authentication/mutual-tls/)
- [FAQ-mTLS](https://istio.io/faq/security/#enabling-disabling-mtls)