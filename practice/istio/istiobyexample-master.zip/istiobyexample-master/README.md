# 例から学ぶIstio

[『Istio By Example』](https://istiobyexample.dev/)サイトの有志による翻訳版となります。

## トラフィック マネージメント

- [カナリアデプロイメント](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/canary.md)
- [gRPC](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/grpc.md)
- [イングレス](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/ingress.md)
- [外部サービス](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/external-services.md)
- [ロードバランシング](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/load-balancing.md)
- [ローカリティロードバランシング](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/locality-load-balancing.md)
- [Pathに基づいたルーティング](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/path-based-routing.md)
- [レスポンスヘッダの変更](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/response-headers.md)
- [再試行ロジック](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/retry.md)
- [フォールトインジェクション](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/fault-injection.md)
- [データベーストラフィック](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/databases.md)
- [トラフィックミラーリング](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/traffic-mirroring.md)
- [イーグレストラフィック監視](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/monitoring-egress-traffic.md)
- [複数トラフィックルール](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/multiple-traffic-rules.md)
- [仮想マシン](https://github.com/cyberblack28/istiobyexample/blob/master/Traffic%20Management/virtual-machines.md)

## セキュリティ

- [相互TLS](https://github.com/cyberblack28/istiobyexample/blob/master/Security/mtls.md)
- [JWT](https://github.com/cyberblack28/istiobyexample/blob/master/Security/jwt.md)
- [認可](https://github.com/cyberblack28/istiobyexample/blob/master/Security/authorization.md)
- [セキュアイングレス](https://github.com/cyberblack28/istiobyexample/blob/master/Security/secure-ingress.md)

## 可観測性

- [持ち込みPrometheus](https://github.com/cyberblack28/istiobyexample/blob/master/Observability/prometheus.md)